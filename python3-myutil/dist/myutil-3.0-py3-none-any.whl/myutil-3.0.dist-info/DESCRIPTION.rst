A python utility package for querying ldap, sending mails and working with files


